"""VAYU Skills CLI & Animated Installer package."""

from __future__ import annotations

__version__ = "1.0.0"
